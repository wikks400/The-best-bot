# Deploying to Botkeep • NFT Mint & Buy Tracker Bot

This project is fully configured for standalone, independent hosting on Botkeep (or any Node.js VPS/hosting provider).

---

## 1. Quick Botkeep Setup Steps

1. **Log in to Botkeep** (https://botkeep.com).
2. Click **Create Bot** / **New Application**.
3. Choose **Node.js** as the environment (Node.js 18.x, 20.x, or 22.x).
4. Upload this ZIP package or extract the files.
5. In the **Startup Command** setting, enter:
   ```bash
   npm start
   ```
   *(Or `npm run bot` — both execute the dedicated headless bot service `src/bot/standalone.ts`)*
6. In the **Environment Variables** section on Botkeep, set:
   - `DISCORD_TOKEN` = Your Discord Bot Token (from Discord Developer Portal)
   - `DISCORD_CLIENT_ID` = Your Discord Application Client ID
   - *(Optional)* `DISCORD_CHANNEL_ID` = Channel ID where NFT alerts should be sent
   - *(Optional)* `DISCORD_WEBHOOK_URL` = Webhook URL (alternative/additional alert destination)
   - *(Optional)* `PORT` = 3000 (if Botkeep uses an HTTP health check probe)
7. Click **Deploy** / **Start**.

---

## 2. Why Wallet Data Is Safe on Botkeep

Unlike Google AI Studio's browser development sandbox (which resets on idle or reload), Botkeep provides a persistent server container. All your tracked wallets, groups, and milestone histories are saved to `data/nft-alert.json`, so your groups and wallets remain saved across bot restarts.

You can also use the Discord slash commands:
- `/wallet-add group:<name> address:<0x...>`
- `/wallet-import group:<name> addresses:<list>`
- `/group-create name:<name>`
- `/alerts-channel channel:<#channel>`
- `/status`

---

## 3. Supported Blockchain Networks (100% Free Public RPCs)
- **Ethereum** (Chain ID: 1)
- **Base** (Chain ID: 8453)
- **Arbitrum One** (Chain ID: 42161)
- **Optimism** (Chain ID: 10)
- **Polygon** (Chain ID: 137)
- **Ink** (Chain ID: 57073)
- **BNB Chain** (Chain ID: 56)
- **Avalanche C-Chain** (Chain ID: 43114)
- **Robinhood Chain** (Chain ID: 4663)

All RPC endpoints use public, rate-limited free tiers with automatic fallbacks and backoff retries.
