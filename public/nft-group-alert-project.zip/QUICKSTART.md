# NFT Group Alert • 24/7 Bot Quickstart Guide

This zip contains the complete source code and standalone Discord bot runner.

## 1. Local or VPS Execution
```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your DISCORD_TOKEN and DISCORD_CLIENT_ID

# 3. Start headless bot runner
npm start
```

## 2. Start Full-Stack Web Dashboard + Bot
```bash
npm run web
# Dashboard opens on http://localhost:3000
```
